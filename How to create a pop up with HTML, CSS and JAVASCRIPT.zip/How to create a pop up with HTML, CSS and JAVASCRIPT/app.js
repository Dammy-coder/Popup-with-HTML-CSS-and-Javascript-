document.getElementById("submit").addEventListener('click', () => {
    document.getElementById('popup-container').classList.add("show-popup");
})

document.getElementById("ok").addEventListener('click', () => {
    document.getElementById('popup-container').classList.remove("show-popup");
})